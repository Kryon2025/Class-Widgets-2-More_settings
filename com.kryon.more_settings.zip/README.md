<div align="center">

<img src="icon.png" height="120" alt="Kryon 的扩展设置">
<h1>
  Kryon的扩展设置
</h1>

[![版本](https://img.shields.io/badge/%E7%89%88%E6%9C%AC-1.3.4-5A9BFF?style=for-the-badge)](https://github.com/Kryon2025/Class-Widgets-2-More_settings/releases)
[![星标](https://img.shields.io/github/stars/Kryon2025/Class-Widgets-2-More_settings?style=for-the-badge&color=orange&label=%E6%98%9F%E6%A0%87)](https://github.com/Kryon2025/Class-Widgets-2-More_settings)
[![开源许可](https://img.shields.io/github/license/Kryon2025/Class-Widgets-2-More_settings?style=for-the-badge&label=%E5%BC%80%E6%BA%90%E8%AE%B8%E5%8F%AF%E8%AF%81)](https://github.com/Kryon2025/Class-Widgets-2-More_settings/blob/main/LICENSE)
[![下载量](https://img.shields.io/github/downloads/Kryon2025/Class-Widgets-2-More_settings/total.svg?label=%E4%B8%8B%E8%BD%BD%E9%87%8F&color=green&style=for-the-badge)](https://github.com/Kryon2025/Class-Widgets-2-More_settings/releases)

</div>

> [!NOTE]
> 当前版本 **1.3.4**，要求 Class Widgets 2 的插件 API `>=0.6.0`。
> 在 [插件广场](https://plaza.cw.rinlit.cn/plugins/com.kryon.more_settings) 可以一键安装/更新，也可以在 Release 页下载 `.cwplugin` 手动导入。

> [!TIP]
> 很抱歉在之前的版本中对大家的影响，现已修复问题，请放心使用！

> [!CAUTION]
> 请注意本插件对于最新版本的支持。如果补丁未注入，请卸载本插件！

## 具体功能

- 组件动画：内置[事件倒计时]组件的数字滚动动画开关。可以避免在课间时造成上课干扰
- 时间组件：为官方内置[时间]组件增加更多功能！丰富使用体验！同样可以关闭动画效果避免造成课程干扰
- 小组件高度 / 隐藏深度：官方暂未提供组件高度自定义。在使用Class Widgets 2时发现默认的隐藏深度和展示宽度可能仍然比较高，故设计此功能
- 特定课程不隐藏：此为1代Class Widgets的设计，但2代并没有，功能适合学校场景使用。点加号从课表科目里选择要排除的科目（最多 20 个，达上限后加号自动禁用）
- 补丁注入检测：若显示为”已注入“则无需关注，如果显示为”未注入“且点击”重新注入补丁“也无效果，请卸载本插件！重复：遇到此情况请卸载此插件！

## 迁移说明

本插件合并了以下四个插件，安装后请**卸载或禁用**它们，避免重复补丁与组件冲突：

- `com.event.countdown.anim`（事件倒计时动画开关）
- `com.kryon.widgets-high`（小组件自定义高度）
- `com.overlay`（堆叠组件）
- `com.time.component`（时间组件）

## 卸载

卸载插件后会自动还原主程序原始 QML（组件动画、小组件高度与堆叠编辑入口一并移除）。

> [!CAUTION]
> 若「补丁注入」状态显示注入失败，请卸载本插件，并反馈给开发者。

## 技术说明

- 主程序补丁：`integrations.py`（幂等、可逆，备份于 `.cwplugin_backups/more_settings/`）
- 补丁状态校验：以实际注入的属性名（`overlayEditingId` / `overlayListMode` 等）为准，避免误报「未注入」
- 配置模型：`more_settings_config.py`（存储于 `plugins.configs.com.kryon.more_settings`）
- 堆叠后端：`overlay_backend.py`
- 设置页 UI：折叠分组基于 RinUI 的 `SettingExpander`；「排除科目」的下拉为原生 `Menu`，采用**预置固定数量项 + `visible` 控制显隐**（不动态增删 menu item，避免渲染异常）